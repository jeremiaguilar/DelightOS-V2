import React from 'react';
import { BarChart3, Flame, Archive, LogOut, Menu, Shield, ShieldAlert, ShoppingBag, Users, Wallet, X, Layers, MapPin } from 'lucide-react';
import POSView from './POSView';
import KdsView from './KdsView';
import ClubDelightView from './ClubDelightView';
import CatalogView from './CatalogView';
import InventoryView from './InventoryView';
import RubricasGerencialesView from './RubricasGerencialesView';
import TicketModal from './TicketModal';
import LoginView from './LoginView';
import { useSystemContext } from '../contexts/SystemContext';
import { useUserContext } from '../contexts/UserContext';
import { useConfigContext } from '../contexts/ConfigContext';
import { useCustomerContext } from '../contexts/CustomerContext';
import { useInventoryContext } from '../contexts/InventoryContext';
import { useOrderContext } from '../contexts/OrderContext';
import { useKDSContext } from '../contexts/KDSContext';
import { useCashRegisterContext } from '../contexts/CashRegisterContext';
import { getRoleDisplayName } from '../utils/roleHelper';
import { saveCachedIngredient, saveCachedProduct } from '../lib/indexedDB';
import { isSupabaseConfigured } from '../lib/supabase';
import { saveIngredientToSupabase, saveProductToSupabase } from '../lib/supabaseService';

function SyncIndicator() {
  const { syncState } = useSystemContext();

  switch (syncState) {
    case 'connected':
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100" title="DelightOS está en línea y conectado a Supabase">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] font-extrabold uppercase tracking-wider">Conectado</span>
        </div>
      );
    case 'offline':
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 text-amber-600 border border-amber-100" title="DelightOS está fuera de línea. Los datos se guardan de forma segura en local">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          <span className="text-[10px] font-extrabold uppercase tracking-wider">Sin conexión</span>
        </div>
      );
    case 'syncing':
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 text-blue-600 border border-blue-100 animate-pulse" title="Sincronizando operaciones pendientes con Supabase">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping" />
          <span className="text-[10px] font-extrabold uppercase tracking-wider">Sincronizando</span>
        </div>
      );
    case 'synced':
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-200" title="Todas las operaciones han sido sincronizadas">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span className="text-[10px] font-extrabold uppercase tracking-wider">Sincronizado</span>
        </div>
      );
    case 'sync_error':
      return (
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-50 text-rose-600 border border-rose-100 animate-pulse" title="Error de sincronización. Hay cambios pendientes que requieren revisión">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-center">Error Sincronización</span>
        </div>
      );
    default:
      return null;
  }
}

function AccessDenied({ role }: { role: string }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-[#FFFDF8]">
      <ShieldAlert className="w-16 h-16 text-red-500 mb-3 animate-bounce" />
      <h3 className="text-sm font-black text-delight-dark uppercase tracking-wider">Acceso Restringido</h3>
      <p className="text-xs text-delight-gray/60 mt-1 max-w-sm">
        Esta sección requiere rol de Administrador o Gerente. Su rol actual es: <strong className="uppercase">{role}</strong>.
      </p>
    </div>
  );
}

const navItems = [
  { id: 'nav-pos', tab: 'pos', label: 'Punto de Venta', icon: ShoppingBag },
  { id: 'nav-kds', tab: 'kds', label: 'Cocina KDS', icon: Flame },
  { id: 'nav-club', tab: 'club', label: 'Club DELIGHT', icon: Users },
  { id: 'nav-catalog', tab: 'catalog', label: 'Catálogo', icon: Layers },
  { id: 'nav-inventory', tab: 'inventory', label: 'Inventario', icon: Archive },
  { id: 'nav-caja', tab: 'caja', label: 'Caja', icon: Wallet },
  { id: 'nav-rubricas', tab: 'rubricas', label: 'Reportes', icon: BarChart3 },
] as const;

export function AppShell() {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const {
    dbState,
    syncState,
    activeTab,
    setActiveTab,
    customers,
    setCustomers,
    ingredients,
    products,
    orders,
    systemConfig,
    auditLogs,
    users,
    soundEnabled,
    setSoundEnabled,
    initializeDatabase,
    addAuditLog,
  } = useSystemContext();

  const { currentUser, login, logout, updateUsers, hasAccess } = useUserContext();
  const { updateConfig } = useConfigContext();
  const { addCustomer, updateCustomer } = useCustomerContext();
  const { addIngredient, updateIngredient, adjustStock, setIngredientsState } = useInventoryContext();
  const {
    rewards,
    selectedOrderForTicket,
    setSelectedOrderForTicket,
    orderCompleted,
    updateProduct,
    updateProductReward,
    applyPointsToCategory,
    resetOfficialRewards,
    setOrdersState,
    setProductsState,
  } = useOrderContext();
  const { activeKdsCount, updateOrderStatus } = useKDSContext();
  const { activeRegister } = useCashRegisterContext();

  if (dbState === 'checking') {
    return (
      <div className="min-h-screen bg-[#FFFDF8] flex flex-col items-center justify-center p-6 text-center animate-fade-in">
        <div className="w-12 h-12 rounded-full border-4 border-delight-green/20 border-t-delight-green animate-spin mb-4" />
        <h3 className="text-sm font-black text-delight-dark uppercase tracking-widest leading-none">Iniciando DelightOS</h3>
        <p className="text-xs text-delight-gray/60 mt-1.5">Verificando base de datos y sincronización...</p>
      </div>
    );
  }

  if (dbState === 'uninitialized') {
    return (
      <div className="min-h-screen bg-[#FFFDF8] flex flex-col items-center justify-center p-6 text-center max-w-md mx-auto">
        <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center mb-5 border border-amber-100 shadow-sm">
          <ShieldAlert className="w-8 h-8 animate-bounce" />
        </div>
        <h2 className="text-lg font-black text-delight-dark uppercase tracking-wider leading-none">Base de datos no inicializada</h2>
        <p className="text-xs text-delight-gray/70 mt-3 leading-relaxed">
          El sistema no pudo conectarse a la base de datos oficial (Supabase) y no existe un respaldo local previo en este navegador. Para poder operar, se requiere una conexión inicial exitosa.
        </p>
        <div className="w-full mt-6 flex flex-col gap-3">
          <button
            type="button"
            onClick={initializeDatabase}
            className="w-full py-3 px-4 bg-delight-dark hover:bg-delight-dark-hover text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-delight-dark/10 flex items-center justify-center gap-2 cursor-pointer"
          >
            Reintentar conexión
          </button>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginView onLoginSuccess={login} />;
  }

  return (
    <div className="min-h-screen bg-[#FFFDF8] flex flex-col overflow-hidden text-delight-dark antialiased">
      <div className="bg-delight-dark text-white py-1 px-4 text-[10px] flex justify-between items-center hidden md:flex font-mono z-40 relative">
        <div className="flex gap-4">
          <span className="flex items-center gap-1.5"><Shield className="w-3 h-3 text-delight-green" /> {currentUser.name} ({currentUser.role})</span>
          <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3 text-delight-yellow" /> {systemConfig?.ticket?.businessName || 'Sucursal Principal'}</span>
        </div>
        <div className="flex gap-4">
          <span className="flex items-center gap-1.5 font-bold uppercase">{activeRegister ? <span className="text-green-400">● Caja Abierta</span> : <span className="text-red-400">● Caja Cerrada</span>}</span>
          <span className="flex items-center gap-1.5 font-bold uppercase">{isSupabaseConfigured ? <span className="text-blue-400">● Nube Activa</span> : <span className="text-amber-400">● Local Mode</span>}</span>
          <span>{syncState && <SyncIndicator />}</span>
        </div>
      </div>

      <header className="h-16 bg-white border-b border-delight-gray/10 flex justify-between items-center px-4 md:px-6 shrink-0 shadow-sm z-30 relative">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-delight-green to-delight-green-hover flex items-center justify-center text-white font-black text-sm shadow-md shadow-delight-green/10">
            D
          </div>
          <div>
            <h1 className="text-sm font-black tracking-tight leading-none text-delight-dark">Delight</h1>
            <span className="text-[10px] font-bold text-delight-green uppercase tracking-widest block mt-0.5">Frappés & Drinks</span>
          </div>
        </div>

        <button className="md:hidden p-2" onClick={() => setMobileMenuOpen((open) => !open)}>
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        <nav className={`fixed inset-x-0 top-16 bg-white border-b p-4 flex-col gap-2 z-40 shadow-xl transition-all md:relative md:top-0 md:bg-delight-dark/5 md:p-1 md:rounded-xl md:flex-row md:flex md:shadow-none ${mobileMenuOpen ? 'flex' : 'hidden md:flex'}`}>
          {navItems.map(({ id, tab, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              id={id}
              onClick={() => {
                setActiveTab(tab as typeof activeTab);
                setMobileMenuOpen(false);
              }}
              className={`py-2 px-4 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all relative cursor-pointer ${
                activeTab === tab ? 'bg-white text-delight-dark shadow-sm' : 'text-delight-gray/70 hover:text-delight-dark'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {label}
              {tab === 'kds' && activeKdsCount > 0 && (
                <span className="absolute -top-1 -right-1.5 bg-red-500 text-white font-extrabold text-[9px] w-5 h-5 rounded-full flex items-center justify-center animate-pulse border-2 border-white">
                  {activeKdsCount}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <div className="hidden sm:block">
            <SyncIndicator />
          </div>

          <div className="text-right hidden sm:block">
            <h5 className="text-xs font-bold text-delight-dark">{currentUser.name}</h5>
            <span className="text-[9px] font-bold text-delight-green uppercase bg-delight-green/10 px-2 py-0.5 rounded">
              {getRoleDisplayName(currentUser.role)}
            </span>
          </div>

          <button
            type="button"
            id="logout-btn"
            onClick={logout}
            className="p-2.5 bg-red-50 hover:bg-red-100 text-red-500 rounded-xl transition-colors cursor-pointer"
            title="Cerrar Sesión (Borra Caché de Sesión)"
          >
            <LogOut className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-hidden">
        {activeTab === 'pos' && (
          <POSView
            customers={customers}
            ingredients={ingredients}
            currentUser={currentUser}
            onOrderCompleted={(newOrder) => orderCompleted(newOrder, currentUser, customers, setCustomers)}
            rewards={rewards}
            products={products}
          />
        )}

        {activeTab === 'kds' && (
          <KdsView
            orders={orders}
            onUpdateOrderStatus={updateOrderStatus}
            onOpenTicket={(order) => setSelectedOrderForTicket(order)}
            soundEnabled={soundEnabled}
            onToggleSound={() => setSoundEnabled(!soundEnabled)}
          />
        )}

        {activeTab === 'club' && (
          <ClubDelightView
            customers={customers}
            orders={orders}
            onAddCustomer={addCustomer}
            onUpdateCustomer={updateCustomer}
            rewards={rewards}
          />
        )}

        {activeTab === 'catalog' && (
          hasAccess(['admin', 'manager']) ? (
            <CatalogView
              products={products}
              ingredients={ingredients}
              onUpdateProduct={updateProduct}
              rewards={rewards}
              onUpdateProductReward={updateProductReward}
              onApplyPointsToCategory={applyPointsToCategory}
              onResetOfficialRewards={resetOfficialRewards}
              onImportCatalog={async (newProducts, updatedProducts, newIngredients) => {
                const combinedProducts = [
                  ...products.filter((product) => !updatedProducts.find((updatedProduct) => updatedProduct.id === product.id)),
                  ...updatedProducts,
                  ...newProducts,
                ];
                setProductsState(combinedProducts);

                const productResults = await Promise.allSettled([
                  ...newProducts.map(async (product) => {
                    await saveCachedProduct(product);
                    await saveProductToSupabase(product);
                  }),
                  ...updatedProducts.map(async (product) => {
                    await saveCachedProduct(product);
                    await saveProductToSupabase(product);
                  }),
                ]);

                const productErrors = productResults.filter((result) => result.status === 'rejected');
                if (productErrors.length > 0) {
                  console.error('Errors saving catalog:', productErrors);
                  throw new Error('Error al guardar productos en Supabase. Ver consola.');
                }

                const combinedIngredients = [...ingredients, ...newIngredients];
                setIngredientsState(combinedIngredients);

                const ingredientResults = await Promise.allSettled(
                  newIngredients.map(async (ingredient) => {
                    await saveCachedIngredient(ingredient);
                    await saveIngredientToSupabase(ingredient);
                  })
                );

                const ingredientErrors = ingredientResults.filter((result) => result.status === 'rejected');
                if (ingredientErrors.length > 0) {
                  console.error('Errors saving ingredients:', ingredientErrors);
                  throw new Error('Error al guardar insumos en Supabase. Ver consola.');
                }

                const { loadProductsFromSupabase } = await import('../lib/supabaseService');
                const reloadedProducts = await loadProductsFromSupabase([]);
                if (reloadedProducts.length > 0) {
                  setProductsState(reloadedProducts);
                  for (const product of reloadedProducts) {
                    await saveCachedProduct(product);
                  }
                }

                await addAuditLog(
                  'IMPORT_CATALOG',
                  `${products.length} productos, ${ingredients.length} insumos`,
                  `${combinedProducts.length} productos, ${combinedIngredients.length} insumos`,
                  'Catalog'
                );
              }}
            />
          ) : (
            <AccessDenied role={getRoleDisplayName(currentUser.role)} />
          )
        )}

        {activeTab === 'inventory' && (
          hasAccess(['admin', 'manager']) ? (
            <InventoryView
              ingredients={ingredients}
              onAddIngredient={addIngredient}
              onUpdateIngredient={updateIngredient}
              onAdjustStock={adjustStock}
            />
          ) : (
            <AccessDenied role={currentUser.role} />
          )
        )}

        {activeTab === 'rubricas' && (
          hasAccess(['admin', 'manager']) ? (
            <RubricasGerencialesView
              orders={orders}
              customers={customers}
              config={systemConfig}
              onUpdateConfig={updateConfig}
              auditLogs={auditLogs}
              currentUser={currentUser}
              users={users}
              onUpdateUsers={updateUsers}
              ingredients={ingredients}
              products={products}
              onUpdateIngredient={updateIngredient}
              onUpdateCustomer={updateCustomer}
              onUpdateOrders={(updatedOrders) => setOrdersState(updatedOrders)}
              addAuditLog={addAuditLog}
              onUpdateProducts={(updated) => {
                setProductsState(updated);
                updated.forEach((product) => saveCachedProduct(product));
              }}
              onUpdateIngredients={(updated) => {
                setIngredientsState(updated);
                updated.forEach((ingredient) => saveCachedIngredient(ingredient));
              }}
            />
          ) : (
            <AccessDenied role={getRoleDisplayName(currentUser.role)} />
          )
        )}
      </main>

      {selectedOrderForTicket && (
        <TicketModal
          order={selectedOrderForTicket}
          config={systemConfig.ticket}
          onClose={() => setSelectedOrderForTicket(null)}
        />
      )}
    </div>
  );
}
