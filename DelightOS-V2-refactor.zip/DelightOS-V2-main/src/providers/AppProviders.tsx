import type { ReactNode } from 'react';
import { CashRegisterProvider } from '../contexts/CashRegisterContext';
import { ClubDelightProvider } from '../contexts/ClubDelightContext';
import { ConfigProvider } from '../contexts/ConfigContext';
import { CustomerProvider } from '../contexts/CustomerContext';
import { InventoryProvider } from '../contexts/InventoryContext';
import { KDSProvider } from '../contexts/KDSContext';
import { OrderProvider } from '../contexts/OrderContext';
import { SystemProvider } from '../contexts/SystemContext';
import { UserProvider } from '../contexts/UserContext';

interface AppProvidersProps {
  children: ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
  return (
    <SystemProvider>
      <ConfigProvider>
        <UserProvider>
          <CustomerProvider>
            <InventoryProvider>
              <CashRegisterProvider>
                <OrderProvider>
                  <KDSProvider>
                    <ClubDelightProvider>{children}</ClubDelightProvider>
                  </KDSProvider>
                </OrderProvider>
              </CashRegisterProvider>
            </InventoryProvider>
          </CustomerProvider>
        </UserProvider>
      </ConfigProvider>
    </SystemProvider>
  );
}
