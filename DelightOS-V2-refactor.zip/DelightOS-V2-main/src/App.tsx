/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppShell } from './components/AppShell';
import { AppProviders } from './providers/AppProviders';

export default function App() {
  return (
    <AppProviders>
      <AppShell />
    </AppProviders>
  );
}
